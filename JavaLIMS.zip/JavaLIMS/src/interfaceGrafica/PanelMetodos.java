package interfaceGrafica;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;

public class PanelMetodos extends JPanel {

	/**
	 * Create the panel.
	 */
	public PanelMetodos() {

		setBounds(275, 150, 400, 400);
		setVisible(true);
		setLayout(null);
		
	}
}
