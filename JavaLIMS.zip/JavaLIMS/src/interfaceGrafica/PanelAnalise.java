package interfaceGrafica;

import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.awt.SystemColor;
import javax.swing.JTextField;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;

import componentesInternos.JTextFieldMod;

import javax.swing.JLabel;

public class PanelAnalise extends JPanel {
	
	public static int qntdColumns = 1;
	public static int qntdRows = 1;
	public static ArrayList<JTextFieldMod> dadosAnalise = new ArrayList<JTextFieldMod>();
	private JTextFieldMod txtInicial;

	/**
	 * Create the panel.
	 */
	public PanelAnalise() {
		
		setForeground(Color.CYAN);
		setBackground(SystemColor.inactiveCaption);
		
		setBounds(275, 150, 1305, 730);
		setLayout(null);
		
		JButton btnAddColumn = new JButton("Add analito");
		btnAddColumn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				for(int i = 0; i < dadosAnalise.size(); i++) {
					remove(dadosAnalise.get(i));
				}
				addColumn();
				for(int i = 0; i < dadosAnalise.size(); i++) {
					add(dadosAnalise.get(i));
				}
				revalidate();
				repaint();
			}
		});
		btnAddColumn.setBounds(1178, 359, 117, 23);
		add(btnAddColumn);
		
		JButton btnAddRow = new JButton("Add amostra");
		btnAddRow.setBounds(642, 696, 131, 23);
		btnAddRow.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				for(int i = 0; i < dadosAnalise.size(); i++) {
					remove(dadosAnalise.get(i));
				}
				addRow();
				for(int i = 0; i < dadosAnalise.size(); i++) {
					add(dadosAnalise.get(i));
					
				}
				revalidate();
				repaint();
			}
		});
		
		add(btnAddRow);
		
		txtInicial = new JTextFieldMod("0,00");
		txtInicial.setBounds(110, 110, 70, 50);
		add(txtInicial);
		txtInicial.setColumns(10);
		dadosAnalise.add(txtInicial);
		
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {		
				for(int i = 0; i < dadosAnalise.size(); i++) {
						dadosAnalise.get(i).setText("X: " + dadosAnalise.get(i).getCoordX() + " Y: " + dadosAnalise.get(i).getCoordY());
				}
			}
		});
		lblNewLabel.setBounds(250, 700, 46, 14);
		add(lblNewLabel);
		
		
	}
	
	public static void addRow() {
		
		JTextFieldMod txtAnalise = new JTextFieldMod("0,00");
		txtAnalise.setVisible(true);
		txtAnalise.setBounds(110, 110 + (qntdRows * 60), 70, 50);
		txtAnalise.setCoordX(qntdColumns);
		txtAnalise.setCoordY(qntdRows);
		dadosAnalise.add(txtAnalise);
		
		for(int i = 0; i < qntdColumns; i++) {
			txtAnalise = new JTextFieldMod("0,00");
			txtAnalise.setVisible(true);
			txtAnalise.setBounds(110 + (i * 80), 110 + (qntdRows * 60), 70, 50);
			txtAnalise.setCoordX(i);
			txtAnalise.setCoordY(qntdRows + 1);
			dadosAnalise.add(txtAnalise);
		}
		
		qntdRows++;
	}
	
	public static void addColumn() {
		
		JTextFieldMod txtAnalise = new JTextFieldMod("0,00");
		txtAnalise.setVisible(true);
		txtAnalise.setBounds(110 + (qntdColumns * 80), 110, 70, 50);
		txtAnalise.setCoordX(qntdColumns);
		txtAnalise.setCoordY(qntdRows);
		dadosAnalise.add(txtAnalise);
		
		for(int i = 0; i < qntdRows; i++) {
			txtAnalise = new JTextFieldMod("0,00");
			txtAnalise.setVisible(true);
			txtAnalise.setBounds(110 + (qntdColumns * 80), 110 + (i * 60), 70, 50);
			txtAnalise.setCoordX(qntdColumns + 1);
			txtAnalise.setCoordY(i);
			dadosAnalise.add(txtAnalise);
		}
		
		qntdColumns++;
	}
}
