package interfaceGrafica;

import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Date;

import componentesInternos.JTextFieldMod;
import java.time.format.DateTimeFormatter;  
import java.time.LocalDateTime;    
import javax.swing.JLabel;
import java.awt.Font;
import com.toedter.calendar.JCalendar;
import java.awt.Label;
import javax.swing.ImageIcon;
import java.awt.Choice;
import java.awt.Canvas;
import javax.swing.JTextField;

public class PanelAnalise extends JPanel {
	
	public static int qntdColumns = 1;
	public static int qntdRows = 1;
	public static ArrayList<JTextFieldMod> dadosAnalise = new ArrayList<JTextFieldMod>();
	private JTextFieldMod txtInicial;
	public static JLabel lblData = new JLabel();
	public static DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	public static LocalDateTime now = LocalDateTime.now();
	public static boolean calendarAtivo;

	/**
	 * Create the panel.
	 */
	public PanelAnalise() {
		
		setForeground(Color.CYAN);
		setBackground(new Color(0.0f, 0.0f, 0.0f, 0.0f));
		setOpaque(false);
		
		setBounds(275, 150, 1305, 730);
		setLayout(null);
		
		JButton btnAddColumn = new JButton("Add analito");
		btnAddColumn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				for(int i = 0; i < dadosAnalise.size(); i++) {
					remove(dadosAnalise.get(i));
				}
				addColumn();
				for(int i = 0; i < dadosAnalise.size(); i++) {
					add(dadosAnalise.get(i));
				}
				revalidate();
				repaint();
			}
		});
		btnAddColumn.setBounds(1178, 359, 117, 23);
		add(btnAddColumn);
		
		JButton btnAddRow = new JButton("Add amostra");
		btnAddRow.setBounds(642, 696, 131, 23);
		btnAddRow.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				for(int i = 0; i < dadosAnalise.size(); i++) {
					remove(dadosAnalise.get(i));
				}
				addRow();
				for(int i = 0; i < dadosAnalise.size(); i++) {
					add(dadosAnalise.get(i));
					
				}
				revalidate();
				repaint();
			}
		});
		
		add(btnAddRow);
		
		txtInicial = new JTextFieldMod("0,00");
		txtInicial.setBounds(180, 180, 110, 50);
		add(txtInicial);
		txtInicial.setColumns(10);
		dadosAnalise.add(txtInicial);
		
		lblData.setFont(new Font("Tahoma", Font.BOLD, 24));
		lblData.setBounds(180, 32, 230, 35);	
		lblData.setText("Data: " + dtf.format(now));
		add(lblData);
		
		
		
		JCalendar calendar = new JCalendar();
		calendar.setBounds(447, 32, 187, 120);
		calendar.setVisible(true);
		calendar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.out.println(calendar.getDate());
				System.out.println(calendar.getDayChooser().getDay());
				System.out.println(calendar.getDayChooser().getDayPanel());

				
				lblData.setText("Data: " + 	calendar.getDayChooser().getDay());
				revalidate();
				repaint();
			}
		});

		JLabel lblIconCalendario = new JLabel("");
		lblIconCalendario.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(calendarAtivo) {
					remove(calendar);
					calendarAtivo = false;
				}else {
					add(calendar);
					calendarAtivo = true;
				}
				revalidate();
				repaint();
			}
		});
		lblIconCalendario.setIcon(new ImageIcon(PanelAnalise.class.getResource("/res/IconCalendar.png")));
		lblIconCalendario.setBounds(409, 32, 32, 32);
		add(lblIconCalendario);
	}
	
	public static void addRow() {
		
		JTextFieldMod txtAnalise = new JTextFieldMod("0,00");
		txtAnalise.setVisible(true);
		txtAnalise.setBounds(180, 180 + (qntdRows * 60), 110, 50);
		dadosAnalise.add(txtAnalise);
		
		for(int i = 1; i < qntdColumns; i++) {
			txtAnalise = new JTextFieldMod("0,00");
			txtAnalise.setVisible(true);
			txtAnalise.setBounds(180 + (i * 120), 180 + (qntdRows * 60), 110, 50);
			dadosAnalise.add(txtAnalise);
		}
		
		qntdRows++;
	}
	
	public static void addColumn() {
				
		JTextFieldMod txtAnalise = new JTextFieldMod("0,00");
		txtAnalise.setVisible(true);
		txtAnalise.setBounds(180 + (qntdColumns * 120), 180, 110, 50);
		dadosAnalise.add(txtAnalise);
		
		for(int i = 1; i < qntdRows; i++) {
			txtAnalise = new JTextFieldMod("0,00");
			txtAnalise.setVisible(true);
			txtAnalise.setBounds(180 + (qntdColumns * 120), 180 + (i * 60), 110, 50);
			dadosAnalise.add(txtAnalise);
		}
		
		qntdColumns++;
	}
	
	public static void applyCoords() {
		
		int menor = Integer.MAX_VALUE;
		int menorAnterior = Integer.MIN_VALUE;
		
		for(int i = 0; i < qntdColumns; i++) {
		
			menor = Integer.MAX_VALUE;
			
			for(int j = 0; j < dadosAnalise.size(); j++) {
				if(dadosAnalise.get(j).getLocation().getX() < menor && dadosAnalise.get(j).getLocation().getX() > menorAnterior) {
					menor = (int) dadosAnalise.get(j).getLocation().getX();
				}
			}

			for(int j = 0; j < dadosAnalise.size(); j++) {
				if(dadosAnalise.get(j).getLocation().getX() == menor) {
					dadosAnalise.get(j).setCoordX(i);
				}
			}
			
			menorAnterior = menor;
		}
		
		menor = Integer.MAX_VALUE;
		menorAnterior = Integer.MIN_VALUE;
		
		for(int i = 0; i < qntdRows; i++) {
			
			menor = Integer.MAX_VALUE;
			
			for(int j = 0; j < dadosAnalise.size(); j++) {
				if(dadosAnalise.get(j).getLocation().getY() < menor && dadosAnalise.get(j).getLocation().getY() > menorAnterior) {
					menor = (int) dadosAnalise.get(j).getLocation().getY();
				}
			}

			for(int j = 0; j < dadosAnalise.size(); j++) {
				if(dadosAnalise.get(j).getLocation().getY() == menor) {
					dadosAnalise.get(j).setCoordY(i);
				}
			}
			
			menorAnterior = menor;
		}
		

		
		System.out.println("Rows: " + qntdRows);
		System.out.println("Columns: " + qntdColumns);
	}
}
