package interfaceGrafica;

import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JMenuBar;
import javax.swing.JPopupMenu;
import java.awt.Component;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Properties;

import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.Popup;

import org.jdatepicker.impl.JDatePanelImpl;
import org.jdatepicker.impl.JDatePickerImpl;
import org.jdatepicker.impl.UtilDateModel;

import componentesInternos.DateLabelFormatter;
import tabelas.Empresa;

import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class PanelTimeline extends JPanel {
	
	public static DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	public static LocalDateTime now = LocalDateTime.now();
	private JDatePickerImpl datePickerFinal;
	public static int diaInicio;
	public static int mesInicio;
	public static int anoInicio;
	public static int diaFinal;
	public static int mesFinal;
	public static int anoFinal;
	
	/**
	 * Create the panel.
	 */
	public PanelTimeline() {

		setBounds(275, 150, 1315, 717);
		setBackground(new Color(0.0f, 0.0f, 0.0f, 0.0f));
		setOpaque(false);
		setVisible(true);
		setLayout(null);
		
		JPanel pnlGrafico = new JPanel();
		pnlGrafico.setBounds(10, 139, 1295, 567);
		pnlGrafico.setBackground(Color.CYAN);
		add(pnlGrafico);
		pnlGrafico.setLayout(null);
		
		UtilDateModel modelInicio = new UtilDateModel();
		modelInicio.setDate(now.getYear(), now.getMonthValue() - 1, now.getDayOfMonth());
		modelInicio.setSelected(true);
		Properties pInicio = new Properties();
		pInicio.put("text.today", "Today");
		pInicio.put("text.month", "Month");
		pInicio.put("text.year", "Year");
		JDatePanelImpl datePanelInicio = new JDatePanelImpl(modelInicio, pInicio);
		JDatePickerImpl datePickerInicio = new JDatePickerImpl(datePanelInicio, new DateLabelFormatter());
		datePickerInicio.getJFormattedTextField().setFont(new Font("Tahoma", Font.BOLD, 24));
		datePickerInicio.setBackground(new Color(0.0f, 0.0f, 0.0f, 0.0f));
		datePickerInicio.setOpaque(false);
		datePickerInicio.getJFormattedTextField().setBackground(new Color(0.0f, 0.0f, 0.0f, 0.0f));
		datePickerInicio.getJFormattedTextField().setForeground(new Color(17, 69, 89));
		datePickerInicio.getJFormattedTextField().setOpaque(false);
		datePickerInicio.setBounds(87, 55, 202, 23);
		datePickerInicio.setVisible(true);
		add(datePickerInicio);
		
		UtilDateModel modelFinal = new UtilDateModel();
		modelFinal.setDate(now.getYear(), now.getMonthValue() - 1, now.getDayOfMonth());
		modelFinal.setSelected(true);
		Properties pFinal = new Properties();
		pFinal.put("text.today", "Today");
		pFinal.put("text.month", "Month");
		pFinal.put("text.year", "Year");
		JDatePanelImpl datePanelFinal = new JDatePanelImpl(modelFinal, pFinal);
		JDatePickerImpl datePickerFinal = new JDatePickerImpl(datePanelFinal, new DateLabelFormatter());
		datePickerFinal.getJFormattedTextField().setFont(new Font("Tahoma", Font.BOLD, 24));
		datePickerFinal.setBackground(new Color(0.0f, 0.0f, 0.0f, 0.0f));
		datePickerFinal.setOpaque(false);
		datePickerFinal.getJFormattedTextField().setBackground(new Color(0.0f, 0.0f, 0.0f, 0.0f));
		datePickerFinal.getJFormattedTextField().setForeground(new Color(17, 69, 89));
		datePickerFinal.getJFormattedTextField().setOpaque(false);
		datePickerFinal.setBounds(399, 55, 202, 23);
		datePickerFinal.setVisible(true);
		add(datePickerFinal);
		
		
		JLabel lblInicio = new JLabel("Inicio");
		lblInicio.setBounds(10, 55, 106, 23);
		lblInicio.setFont(new Font("Tahoma", Font.BOLD, 24));
		lblInicio.setForeground(new Color(17, 69, 89));
		add(lblInicio);
		
		JLabel lblFinal = new JLabel("Final");
		lblFinal.setForeground(new Color(17, 69, 89));
		lblFinal.setFont(new Font("Tahoma", Font.BOLD, 24));
		lblFinal.setBounds(339, 55, 106, 23);
		add(lblFinal);
		
		JComboBox cmbAnalito = new JComboBox();
		cmbAnalito.setFont(new Font("Tahoma", Font.PLAIN, 16));
		cmbAnalito.setModel(new DefaultComboBoxModel(new String[] {"Analito"}));
		cmbAnalito.setBounds(653, 55, 236, 23);
		cmbAnalito.setFont(new Font("Tahoma", Font.BOLD, 16));
		cmbAnalito.setForeground(new Color(17, 69, 89));
		add(cmbAnalito);
		
		JComboBox cmbAmostra = new JComboBox();
		cmbAmostra.setModel(new DefaultComboBoxModel(new String[] {"Amostra"}));
		cmbAmostra.setBounds(899, 55, 236, 23);
		cmbAmostra.setFont(new Font("Tahoma", Font.BOLD, 16));
		cmbAmostra.setForeground(new Color(17, 69, 89));
		add(cmbAmostra);
		
		JButton btnGerarGrafico = new JButton("GERAR GR�FICO");
		btnGerarGrafico.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				diaInicio = modelInicio.getDay();
				mesInicio = modelInicio.getMonth();
				anoInicio = modelInicio.getYear();
				diaFinal = modelFinal.getDay();
				mesFinal = modelFinal.getMonth();
				anoFinal = modelFinal.getYear();
			}
		});
		btnGerarGrafico.setBounds(1148, 11, 157, 117);
		add(btnGerarGrafico);

	}
}
