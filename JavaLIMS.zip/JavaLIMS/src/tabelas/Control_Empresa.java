package tabelas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;



public class Control_Empresa {

	
	public static void inserir(Empresa empresa) {
		try {
		Connection connection = ConexaoUtil.getInstance().getConnection();
		
		String sql  = "insert into Empresa(idEmpresa,Nome,Cnpj,Email,Analise)values (?,?,?,?,?)";
		
		PreparedStatement statement = connection.prepareStatement(sql);
	
		statement.setInt(1, empresa.getIdEmpresa());
		statement.setString(2,empresa.getNome());
		statement.setString(3,empresa.getCnpj());
		statement.setString(4,empresa.getEmail());
		
		statement.execute();
		connection.close();
		
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	public static void remover(int idEmpresa) {
		try {
			Connection connection = ConexaoUtil.getInstance().getConnection();
			String sql = "delete from Empresa where idEmpresa = ?";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setInt(1, idEmpresa);
			statement.execute();
			statement.close();
		}catch (Exception e) {
		}
	}
	  public static List<Empresa> listarTodos(){
		
		List<Empresa> listarEmpresas = new ArrayList<Empresa>();
		try {
			Connection connection = ConexaoUtil.getInstance().getConnection();
			String sql = "select * from Empresa";
			
			PreparedStatement statement = connection.prepareStatement(sql);
			ResultSet resultset = statement.executeQuery();
			while(resultset.next()) {
				
			Empresa empresa = new Empresa();
			empresa.setIdEmpresa(resultset.getInt(1));
			empresa.setNome(resultset.getString("Vinil"));
			empresa.setCnpj(resultset.getString("66666666"));
			empresa.setEmail(resultset.getString("ffdsddss"));
			
			listarEmpresas.add(empresa);
			
		}
		connection.close();
	}catch (Exception e) {
		e.printStackTrace();
	}
		return listarEmpresas;
	  }
	  public void atualizar (Empresa empresa) {
		  
		  try {
			  
			  Connection connection = ConexaoUtil.getInstance().getConnection();
			  String sql = "update Empresa set idEmpresa = ? where idEmpresa =?";
			  PreparedStatement statement = connection.prepareStatement(sql);
			  
			  statement.setInt(1,empresa.getIdEmpresa());
			  statement.setString(2,empresa.getNome());

			    statement.execute();
				statement.close();		
			  
		  }catch(Exception e) {
			  e.printStackTrace();
		  }
		  
		  
	  }
}

