package tabelas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class Control_Empresa {

	
	public static void inserir(Empresa empresa) {
		try {
		Connection connection = ConexaoUtil.getInstance().getConnection();
		
		String sql  = "insert into Empresa(idEmpresa, nome, cnpj, email, fk_idLaboratorio) values (?,?,?,?,?)";
		
		PreparedStatement statement = connection.prepareStatement(sql);
	
		statement.setInt(1, empresa.getIdEmpresa());
		statement.setString(2,empresa.getNome());
		statement.setString(3,empresa.getCnpj());
		statement.setString(4,empresa.getEmail());
		statement.setString(5, null);
		
		statement.execute();
		connection.close();
		
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	public static void remover(int idEmpresa) {
		try {
			Connection connection = ConexaoUtil.getInstance().getConnection();
			String sql = "delete from Empresa where idEmpresa = ?";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setInt(1, idEmpresa);
			statement.execute();
			statement.close();
		}catch (Exception e) {
		}
	}
	  public static ArrayList<Empresa> listarTodos(){
		
		ArrayList<Empresa> listarEmpresas = new ArrayList<Empresa>();
		try {
			Connection connection = ConexaoUtil.getInstance().getConnection();
			String sql = "select * from Empresa";
			
			PreparedStatement statement = connection.prepareStatement(sql);
			ResultSet resultset = statement.executeQuery();
			while(resultset.next()) {
				
			Empresa empresa = new Empresa();
			empresa.setIdEmpresa(resultset.getInt(1));
			empresa.setNome(resultset.getString("Nome"));
			empresa.setCnpj(resultset.getString("Cnpj"));
			empresa.setEmail(resultset.getString("Email"));
			
			listarEmpresas.add(empresa);
			
		}
		connection.close();
	}catch (Exception e) {
		e.printStackTrace();
	}
		return listarEmpresas;
	  }
	  public void atualizar (Empresa empresa) {
		  
		  try {
			  
			  Connection connection = ConexaoUtil.getInstance().getConnection();
			  String sql = "update Empresa set idEmpresa = ? where idEmpresa =?";
			  PreparedStatement statement = connection.prepareStatement(sql);
			  
			  statement.setInt(1,empresa.getIdEmpresa());
			  statement.setString(2,empresa.getNome());

			    statement.execute();
				statement.close();		
			  
		  }catch(Exception e) {
			  e.printStackTrace();
		  }
		  
		  
	  }
}

