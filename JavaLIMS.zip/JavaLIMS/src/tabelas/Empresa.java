package tabelas;

public class Empresa {

	private int idEmpresa;
	private String nome;
	private String cnpj;
	private String email;
	private int fk_idLaboratorio;
	
	public int getIdEmpresa() {
		return idEmpresa;
	}
	public void setIdEmpresa(int idEmpresa) {
		this.idEmpresa = idEmpresa;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCnpj() {
		return cnpj;
	}
	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getFk_idLaboratorio() {
		return fk_idLaboratorio;
	}
	public void setFk_idLaboratorio(int fk_idLaboratorio) {
		this.fk_idLaboratorio = fk_idLaboratorio;
	}
	
}
