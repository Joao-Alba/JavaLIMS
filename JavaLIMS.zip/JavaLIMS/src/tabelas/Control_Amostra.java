package tabelas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;



public class Control_Amostra {

	
	public static void inserir(Amostra maquinas) {
		try {
		Connection connection = ConexaoUtil.getInstance().getConnection();
		
		String sql  = "insert into Maquinas (idMaquinas,Tipo,Marca,Modelo)values (?,?,?,?)";
		
		PreparedStatement statement = connection.prepareStatement(sql);
	
		statement.setInt(1, maquinas.getIdAmostra());
		statement.setString(2, maquinas.getTipo());
		statement.setString(3, maquinas.getMarca());
		statement.setString(4, maquinas.getModelo());
		
		statement.execute();
		connection.close();
		
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	public static  void remover(int idMaquinas) {
		try {
			Connection connection = ConexaoUtil.getInstance().getConnection();
			String sql = "delete from Maquinas where idMaquinas= ?";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setInt(1, idMaquinas);
			
			statement.execute();
			statement.close();
		}catch (Exception e) {
		}
	}
	  public List<Amostra> listarTodos(){
		
		List<Amostra> listarMaquinas = new ArrayList<Amostra>();
		try {
			Connection connection = ConexaoUtil.getInstance().getConnection();
			String sql = "select * from Maquinas";
			
			PreparedStatement statement = connection.prepareStatement(sql);
			ResultSet resultset = statement.executeQuery();
			while(resultset.next()) {
				
			Amostra  maquina = new Amostra();
			maquina.setIdAmostra(resultset.getInt(1));
			maquina.setTipo(resultset.getString("Crossy"));
			maquina.setMarca(resultset.getString("Still"));
			maquina.setModelo(resultset.getString("Cv40"));
			
			
			listarMaquinas.add(maquina);
			
		}
		connection.close();
	}catch (Exception e) {
		e.printStackTrace();
	}
		return listarMaquinas;
	  }
	  public static  void atualizar (Amostra maquina) {
		  
		  try {
			  
			  Connection connection = ConexaoUtil.getInstance().getConnection();
			  String sql = "update Maquina set idMaquinas = ? where idMaquinas =?";
			  PreparedStatement statement = connection.prepareStatement(sql);
			  
			  statement.setInt(1, maquina.getIdAmostra());
			  statement.setString(2,maquina.getTipo());
			  statement.setString(2,maquina.getMarca());
			  statement.setString(2,maquina.getModelo());
			  

			    statement.execute();
				statement.close();		
			  
		  }catch(Exception e) {
			  e.printStackTrace();
		  }
		  
		  
	  }
}
