package tabelas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class Control_Amostra {

	
	public static void inserir(Amostra amostra) {
		try {
		Connection connection = ConexaoUtil.getInstance().getConnection();
		
		String sql  = "insert into Maquinas (idAmostra, nome, Y, fk_idEmpresa)values (?,?,?,?)";
		
		PreparedStatement statement = connection.prepareStatement(sql);
	
		statement.setInt(1, amostra.getIdAmostra());
		statement.setString(2, amostra.getNome());
		statement.setInt(3, amostra.getY());
		statement.setInt(4, amostra.getFk_idEmpresa());
		
		statement.execute();
		connection.close();
		
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	public static  void remover(int idMaquinas) {
		try {
			Connection connection = ConexaoUtil.getInstance().getConnection();
			String sql = "delete from Maquinas where idMaquinas= ?";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setInt(1, idMaquinas);
			
			statement.execute();
			statement.close();
		}catch (Exception e) {
		}
	}
	  public ArrayList<Amostra> listarTodos(){
		
		ArrayList<Amostra> listarAmostras = new ArrayList<Amostra>();
		try {
			Connection connection = ConexaoUtil.getInstance().getConnection();
			String sql = "select * from Amostra";
			
			PreparedStatement statement = connection.prepareStatement(sql);
			ResultSet resultset = statement.executeQuery();
			while(resultset.next()) {
				
			Amostra amostra = new Amostra();
			amostra.setIdAmostra(resultset.getInt("idAmostra"));
			amostra.setNome(resultset.getString("nome"));
			amostra.setY(resultset.getInt("Y"));
			amostra.setFk_idEmpresa(resultset.getInt("fk_idEmpresa"));
			
			
			listarAmostras.add(amostra);
			
		}
		connection.close();
	}catch (Exception e) {
		e.printStackTrace();
	}
		return listarAmostras;
	  }
	  public static  void atualizar (Amostra maquina) {
		  
		  try {
			  
			  Connection connection = ConexaoUtil.getInstance().getConnection();
			  String sql = "update Maquina set idMaquinas = ? where idMaquinas =?";
			  PreparedStatement statement = connection.prepareStatement(sql);
			  
			  statement.setInt(1, maquina.getIdAmostra());
			  

			    statement.execute();
				statement.close();		
			  
		  }catch(Exception e) {
			  e.printStackTrace();
		  }
		  
		  
	  }
}
