package tabelas;

public class Analise {

	
	private int idAnalise;
	private String Data;
	private double qtdElemento;
	private int fk_idAmostra;
	private int fk_idUsuario;
	private int fk_idAnalito;
	private int fk_idEmpresa;
	public int getIdAnalise() {
		return idAnalise;
	}
	public void setIdAnalise(int idAnalise) {
		this.idAnalise = idAnalise;
	}
	public String getData() {
		return Data;
	}
	public void setData(String data) {
		Data = data;
	}
	public double getQtdElemento() {
		return qtdElemento;
	}
	public void setQtdElemento(double qtdElemento) {
		this.qtdElemento = qtdElemento;
	}
	public int getFk_idAmostra() {
		return fk_idAmostra;
	}
	public void setFk_idAmostra(int fk_idAmostra) {
		this.fk_idAmostra = fk_idAmostra;
	}
	public int getFk_idUsuario() {
		return fk_idUsuario;
	}
	public void setFk_idUsuario(int fk_idUsuario) {
		this.fk_idUsuario = fk_idUsuario;
	}
	public int getFk_idAnalito() {
		return fk_idAnalito;
	}
	public void setFk_idAnalito(int fk_idAnalito) {
		this.fk_idAnalito = fk_idAnalito;
	}
	public int getFk_idEmpresa() {
		return fk_idEmpresa;
	}
	public void setFk_idEmpresa(int fk_idEmpresa) {
		this.fk_idEmpresa = fk_idEmpresa;
	}
	
	
	
	
	
	
}
	
	
	
	
	
	
	
	
	
	
	
	

