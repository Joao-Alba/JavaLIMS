package tabelas;

public class Analise {

	private int idAnalise;
	private int dia;
	private int mes;
	private int ano;
	private double valor;
	private int fk_idAmostra;
	private int fk_idAnalito;
	private int fk_idEmpresa;
	private int fk_idUsuario;
	
	public int getIdAnalise() {
		return idAnalise;
	}
	public void setIdAnalise(int idAnalise) {
		this.idAnalise = idAnalise;
	}
	public int getDia() {
		return dia;
	}
	public void setDia(int dia) {
		this.dia = dia;
	}
	public int getMes() {
		return mes;
	}
	public void setMes(int mes) {
		this.mes = mes;
	}
	public int getAno() {
		return ano;
	}
	public void setAno(int ano) {
		this.ano = ano;
	}
	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}
	public int getFk_idAmostra() {
		return fk_idAmostra;
	}
	public void setFk_idAmostra(int fk_idAmostra) {
		this.fk_idAmostra = fk_idAmostra;
	}
	public int getFk_idUsuario() {
		return fk_idUsuario;
	}
	public void setFk_idUsuario(int fk_idUsuario) {
		this.fk_idUsuario = fk_idUsuario;
	}
	public int getFk_idAnalito() {
		return fk_idAnalito;
	}
	public void setFk_idAnalito(int fk_idAnalito) {
		this.fk_idAnalito = fk_idAnalito;
	}
	public int getFk_idEmpresa() {
		return fk_idEmpresa;
	}
	public void setFk_idEmpresa(int fk_idEmpresa) {
		this.fk_idEmpresa = fk_idEmpresa;
	}
	
	
	
	
	
	
}
	
	
	
	
	
	
	
	
	
	
	
	

