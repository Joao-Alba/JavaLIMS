package tabelas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


public class Control_Usuario {

	
	public static  void inserir(Usuario usuario) {
		try {
		Connection connection = ConexaoUtil.getInstance().getConnection();
		
		String sql  = "insert into Usuario(idUsuario,Nome,Cpf,Senha)values (?,?,?,?)";
		
		PreparedStatement statement = connection.prepareStatement(sql);
	
		statement.setInt(1, usuario.getIdUsuario());
		statement.setString(2, usuario.getNome());
		statement.setInt(3, usuario.getCpf());
		statement.setString(4, usuario.getSenha());
		
		
		
		
		statement.execute();
		connection.close();
		
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	public static void remover(int idUsuario) {
		try {
			Connection connection = ConexaoUtil.getInstance().getConnection();
			String sql = "delete from Usuario where idUsuario = ?";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setInt(1,idUsuario);
			statement.execute();
			statement.close();
		}catch (Exception e) {
		}
	}
	  public static List<Usuario> listarTodos(){
		
		List<Usuario> listarUsuario = new ArrayList<Usuario>();
		try {
			Connection connection = ConexaoUtil.getInstance().getConnection();
			String sql = "select * from Usuario";
			
			PreparedStatement statement = connection.prepareStatement(sql);
			ResultSet resultset = statement.executeQuery();
			while(resultset.next()) {
				
			Usuario usuario = new Usuario();
			usuario.setIdUsuario(resultset.getInt(1));
			usuario.setNome(resultset.getString("xequenal"));
			usuario.setCpf(resultset.getInt(464445555));
			usuario.setSenha(resultset.getString("cav"));
			
			listarUsuario.add(usuario);
			
		}
		connection.close();
	}catch (Exception e) {
		e.printStackTrace();
	}
		return listarUsuario;
	  }
	  public void atualizar (Usuario usuario) {
		  
		  try {
			  
			  Connection connection = ConexaoUtil.getInstance().getConnection();
			  String sql = "update Usuario set idUsuario = ? where idUsuario =?";
			  PreparedStatement statement = connection.prepareStatement(sql);
			  
			  statement.setInt(1,usuario.getIdUsuario());
			  statement.setString(2,usuario.getNome());
			  statement.setInt(3,usuario.getCpf());
			  statement.setString(4,usuario.getSenha());
			  
			  

			    statement.execute();
				statement.close();		
			  
		  }catch(Exception e) {
			  e.printStackTrace();
		  }
		  
		  
	  }
	  public static void main(String[]args) {
		  
		  Usuario usuario = new Usuario();
		  usuario.setIdUsuario(1);
		  usuario.setNome("dorvalino");
		  usuario.setCpf(11564546);
		  usuario.setSenha("cav");
		  inserir(usuario);
		 
		  
	  }
}

