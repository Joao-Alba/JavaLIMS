package tabelas;

public class Padrao {

	
	private int idPadrao;
	private int fk_idAnalito;
	private int  fk_idAmostra;
	private double maximo;
	private double minimo;
	
	
	public int getIdPadrao() {
		return idPadrao;
	}
	public void setIdPadrao(int idPadrao) {
		this.idPadrao = idPadrao;
	}
	public int getFk_idAnalito() {
		return fk_idAnalito;
	}
	public void setFk_idAnalito(int idAnalito) {
		this.fk_idAnalito = idAnalito;
	}
	public int getFk_IdAmostra() {
		return fk_idAmostra;
	}
	public void setFk_idAmostra(int fk_idAmostra) {
		this.fk_idAmostra = fk_idAmostra;
	}
	public double getMaximo() {
		return maximo;
	}
	public void setMaximo(double maximo) {
		this.maximo = maximo;
	}
	public double getMinimo() {
		return minimo;
	}
	public void setMinimo(double minimo) {
		this.minimo = minimo;
	}
	
	
	
	
	
	
}