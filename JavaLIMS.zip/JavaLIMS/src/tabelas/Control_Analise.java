package tabelas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class Control_Analise {
	
	public static void inserir(Analise analise) {
		try {
		Connection connection = ConexaoUtil.getInstance().getConnection();
		
		String sql  = "insert into Analise(idAnalise, dia, mes, ano, valor, fk_idAmostra, fk_idAnalito, fk_idEmpresa, fk_idUsuario) values (?,?,?,?,?,?,?,?,?)";
		
		PreparedStatement statement = connection.prepareStatement(sql);
	
		statement.setInt(1, analise.getIdAnalise());
		statement.setInt(2, analise.getDia());
		statement.setInt(3, analise.getMes());
		statement.setInt(4, analise.getAno());
		statement.setDouble(5, analise.getValor());
		statement.setInt(6, analise.getFk_idAmostra());
		statement.setInt(7, analise.getFk_idAnalito());
		statement.setInt(8, analise.getFk_idUsuario());
		statement.setInt(9, analise.getFk_idEmpresa());

		statement.execute();
		connection.close();
		
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public static void remover(int idAnalise) {
		try {
			Connection connection = ConexaoUtil.getInstance().getConnection();
			String sql = "delete from Analise where idAnalise = ?";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setInt(1,idAnalise);
			
			
			
			statement.execute();
			statement.close();
		}catch (Exception e) {
		}
	}
	  public ArrayList<Analise> listarTodos(){
		
		ArrayList<Analise> listarAnalise = new ArrayList<Analise>();
		try {
			Connection connection = ConexaoUtil.getInstance().getConnection();
			String sql = "select * from Analise";
			
			PreparedStatement statement = connection.prepareStatement(sql);
			ResultSet resultset = statement.executeQuery();
			while(resultset.next()) {
				
			Analise analise = new Analise();
			analise.setIdAnalise(resultset.getInt("idAnalise"));
			analise.setDia(resultset.getInt("dia"));
			analise.setMes(resultset.getInt("mes"));
			analise.setAno(resultset.getInt("ano"));
			analise.setValor(resultset.getDouble("valor"));
			analise.setFk_idAmostra(resultset.getInt("fk_idAmostra"));
			analise.setFk_idAnalito(resultset.getInt("fk_idAnalito"));
			analise.setFk_idEmpresa(resultset.getInt("fk_idEmpresa"));
			analise.setFk_idUsuario(resultset.getInt("fk_idUsuario"));

			listarAnalise.add(analise);
			
		}
		connection.close();
	}catch (Exception e) {
		e.printStackTrace();
	}
		return listarAnalise;
	  }
	  public static void atualizar (Analise analises) {
		  
		  try {
			  
			  Connection connection = ConexaoUtil.getInstance().getConnection();
			  String sql = "update analise set idAnalise = ? where idAnalise =?";
			  PreparedStatement statement = connection.prepareStatement(sql);
			  
			  statement.setInt(1,analises.getIdAnalise());
			  statement.setInt(2,analises.getFk_idAmostra());
			  statement.setInt(3,analises.getFk_idUsuario());
			  statement.setInt(5,analises.getFk_idAnalito());
			  
			  

			    statement.execute();
				statement.close();		
			  
		  }catch(Exception e) {
			  e.printStackTrace();
		  }
		  
		  
	  }
}
	