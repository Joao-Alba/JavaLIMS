package tabelas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;



public class Control_Analise {
	
	public static void inserir(Analise analise) {
		try {
		Connection connection = ConexaoUtil.getInstance().getConnection();
		
		String sql  = "insert into Analise(idAnalise,amostra,Data, Analise_idUsuario, Analise_idAnalito ) values (?,?,?,?,?)";
		
		PreparedStatement statement = connection.prepareStatement(sql);
	
		statement.setInt(1, analise.getIdAnalise());
		statement.setInt(2, analise.getFk_idAmostra());
		statement.setString(3,analise.getData());
		statement.setInt(4, analise.getFk_idUsuario());
		statement.setInt(5, analise.getFk_idAnalito());
		
		
		
		
		
		statement.execute();
		connection.close();
		
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public static void remover(int idAnalise) {
		try {
			Connection connection = ConexaoUtil.getInstance().getConnection();
			String sql = "delete from Analise where idAnalise = ?";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setInt(1,idAnalise);
			
			
			
			statement.execute();
			statement.close();
		}catch (Exception e) {
		}
	}
	  public List<Analise> listarTodos(){
		
		List<Analise> listarAnalise = new ArrayList<Analise>();
		try {
			Connection connection = ConexaoUtil.getInstance().getConnection();
			String sql = "select * from  Analise";
			
			PreparedStatement statement = connection.prepareStatement(sql);
			ResultSet resultset = statement.executeQuery();
			while(resultset.next()) {
				
			Analise analise = new Analise();
			analise.setIdAnalise(resultset.getInt("idAnalise"));
			analise.setFk_idAmostra(resultset.getInt("amostra"));
			
			listarAnalise.add(analise);
			
		}
		connection.close();
	}catch (Exception e) {
		e.printStackTrace();
	}
		return listarAnalise;
	  }
	  public static void atualizar (Analise analises) {
		  
		  try {
			  
			  Connection connection = ConexaoUtil.getInstance().getConnection();
			  String sql = "update analise set idAnalise = ? where idAnalise =?";
			  PreparedStatement statement = connection.prepareStatement(sql);
			  
			  statement.setInt(1,analises.getIdAnalise());
			  statement.setInt(2,analises.getFk_idAmostra());
			  statement.setString(4,analises.getData());
			  statement.setInt(3,analises.getFk_idUsuario());
			  statement.setInt(5,analises.getFk_idAnalito());
			  
			  

			    statement.execute();
				statement.close();		
			  
		  }catch(Exception e) {
			  e.printStackTrace();
		  }
		  
		  
	  }
}
	