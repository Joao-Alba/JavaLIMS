package tabelas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;



public class Control_Analito {

	public static void inserir(Analito analito) {
		try {
		Connection connection = ConexaoUtil.getInstance().getConnection();
		
		String sql  = "insert into Analito( idAnalito,Nome,Fluxograma) values (?,?,?)";
		
		PreparedStatement statement = connection.prepareStatement(sql);
	
		statement.setInt(1, analito.getIdAnalito());
		statement.setString(2, analito.getNome());
		statement.setString(3, analito.getFluxograma());
	
		
		
	
		statement.execute();
		connection.close();
		
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	public static void remover(int idAnalito) {
		try {
			Connection connection = ConexaoUtil.getInstance().getConnection();
			String sql = "delete from Analito where idAnalito = ?";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setInt(1, idAnalito);
			
			statement.execute();
			statement.close();
		}catch (Exception e) {
		}
	}
	  public static List<Analito> listarTodos(){
		
		List<Analito> listarAnalito = new ArrayList<Analito>();
		try {
			Connection connection = ConexaoUtil.getInstance().getConnection();
			String sql = "select * from Analito";
			
			PreparedStatement statement = connection.prepareStatement(sql);
			ResultSet resultset = statement.executeQuery();
			
			while(resultset.next()) {
				
			Analito analito = new Analito();
			analito.setIdAnalito(resultset.getInt("idAnalito"));
			analito.setNome(resultset.getString("nome"));
			//analito.setFluxograma(resultset.getString("ferro"));
			
			listarAnalito.add(analito);
			
		}
		connection.close();
	}catch (Exception e) {
		e.printStackTrace();
	}
		return listarAnalito;
	  }
	  public static void atualizar (Analito analito) {
		  
		  try {
			  
			  Connection connection = ConexaoUtil.getInstance().getConnection();
			  String sql = "update Analito set nome = ? where idAnalito =?";
			  PreparedStatement statement = connection.prepareStatement(sql);
			  
			  statement.setString(1,analito.getNome());
			  statement.setInt(2,analito.getIdAnalito());

			    statement.execute();
				statement.close();		
			  
		  }catch(Exception e) {
			  e.printStackTrace();
		  }
		  
		  
	  }
	  public static void main(String[]args) {
		  
		  Analito analito = new Analito();
		  analito.setIdAnalito(1);
		  analito.setNome("lucas");
		  analito.setFluxograma("turbinado");
		  //atualizar(analito);
		  inserir(analito);
		  
		  
	
		 
	  }
}