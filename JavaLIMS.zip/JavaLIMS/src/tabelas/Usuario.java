package tabelas;

public class Usuario {

	private int idUsuario;
	private String nome;
	private String cpf;
	private String senha;
	private int fk_idLaboratorio;
	
	public int getIdUsuario() {
		return idUsuario;
	}
	public void setIdUsuario(int idUsuario) {
		this.idUsuario = idUsuario;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}
	public int getFk_idLaboratorio() {
		return fk_idLaboratorio;
	}
	public void setFk_idLaboratorio(int fk_idLaboratorio) {
		this.fk_idLaboratorio = fk_idLaboratorio;
	}  
}
