package tabelas;

public class Reagente {

	private int idReagente;
	private String nome;
	private String formula;
	private String precaucao;
	private String molaridade;
	private double qtd_Minima;
	private double qtd_Atual;
	private String preparador;
	private int fk_idLaboratorio;
	
	public double getQtd_Minima() {
		return qtd_Minima;
	}
	public void setQtd_Minima(double qtd_Minima) {
		this.qtd_Minima = qtd_Minima;
	}
	
	public double getQtd_Atual() {
		return qtd_Atual;
	}
	public void setQtd_Atual(double qtd_Atual) {
		this.qtd_Atual = qtd_Atual;
	}
	public int getIdReagente() {
		return idReagente;
	}
	public void setIdReagente(int idReagente) {
		this.idReagente = idReagente;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getFormula() {
		return formula;
	}
	public void setFormula(String formula) {
		this.formula = formula;
	}
	public String getPrecaucao() {
		return precaucao;
	}
	public void setPrecaucao(String precaucao) {
		this.precaucao = precaucao;
	}
	public String getMolaridade() {
		return molaridade;
	}
	public void setMolaridade(String molaridade) {
		this.molaridade = molaridade;
	}
	public String getPreparador() {
		return preparador;
	}
	public void setPreparador(String preparador) {
		this.preparador = preparador;
	}
	public int getFk_idLaboratorio() {
		return fk_idLaboratorio;
	}
	public void setFk_idLaboratorio(int fk_idLaboratorio) {
		this.fk_idLaboratorio = fk_idLaboratorio;
	}
}

