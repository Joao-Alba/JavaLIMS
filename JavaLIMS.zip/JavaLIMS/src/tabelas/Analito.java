package tabelas;

public class Analito {

	private int  idAnalito;
	private String Nome;
	private String fluxograma;
	
	
	
	public int getIdAnalito() {
		return idAnalito;
	}
	public void setIdAnalito(int idAnalito) {
		this.idAnalito = idAnalito;
	}
	public String getNome() {
		return Nome;
	}
	public void setNome(String nome) {
		this.Nome = nome;
	}
	public String getFluxograma() {
		return fluxograma;
	}
	public void setFluxograma(String fluxograma) {
		this.fluxograma = fluxograma;
	}
	
	
	
	
	
}
