package tabelas;

import java.sql.Blob;

public class Analito {

	private int  idAnalito;
	private String nome;
	private Blob fluxograma;
	private int X;
	private int fk_idEmpresa;
	
	public int getIdAnalito() {
		return idAnalito;
	}
	public void setIdAnalito(int idAnalito) {
		this.idAnalito = idAnalito;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public Blob getFluxograma() {
		return fluxograma;
	}
	public void setFluxograma(Blob fluxograma) {
		this.fluxograma = fluxograma;
	}
	public int getX() {
		return X;
	}
	public void setX(int x) {
		X = x;
	}
	public int getFk_idEmpresa() {
		return fk_idEmpresa;
	}
	public void setFk_idEmpresa(int fk_idEmpresa) {
		this.fk_idEmpresa = fk_idEmpresa;
	}
}
