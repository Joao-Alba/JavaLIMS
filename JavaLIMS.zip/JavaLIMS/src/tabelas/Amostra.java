package tabelas;

public class Amostra {

	
	 private int idAmostra;
	 private String nome;
	 private int Y;
	 private int fk_idEmpresa;
	 
	public int getIdAmostra() {
		return idAmostra;
	}
	public void setIdAmostra(int idAmostra) {
		this.idAmostra = idAmostra;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getY() {
		return Y;
	}
	public void setY(int y) {
		Y = y;
	}
	public int getFk_idEmpresa() {
		return fk_idEmpresa;
	}
	public void setFk_idEmpresa(int fk_idEmpresa) {
		this.fk_idEmpresa = fk_idEmpresa;
	} 
}
