package tabelas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class Control_Laboratorio {

	
	public  static void inserir(Laboratorio laboratorio) {
		try {
		Connection connection = ConexaoUtil.getInstance().getConnection();
		
		String sql  = "insert into Laboratorio(idLaboratorio,  Laboratorio_idUsuario, Laboratorio_idEmpresa)values (?,?,?)";
		
		PreparedStatement statement = connection.prepareStatement(sql);
	
		statement.setInt(1, laboratorio.getIdLaboratorio());
		
		statement.execute();
		connection.close();
		
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	public static  void remover(int idLaboratorio) {
		try {
			Connection connection = ConexaoUtil.getInstance().getConnection();
			String sql = "delete from Laboratorio where idLaboratorio = ?";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setInt(1, idLaboratorio);
			
			statement.execute();
			statement.close();
		}catch (Exception e) {
		}
	}
	  public static  List<Laboratorio> listarTodos(){
		
		List<Laboratorio> listarLaboratorio = new ArrayList<Laboratorio>();
		try {
			Connection connection = ConexaoUtil.getInstance().getConnection();
			String sql = "select * from laboratorio";
			
			PreparedStatement statement = connection.prepareStatement(sql);
			ResultSet resultset = statement.executeQuery();
			while(resultset.next()) {
				
			Laboratorio laboratorio = new Laboratorio();
			laboratorio.setIdLaboratorio(resultset.getInt(1));
			
			listarLaboratorio.add(laboratorio);
			
		}
		connection.close();
	}catch (Exception e) {
		e.printStackTrace();
	}
		return listarLaboratorio;
	  }
	  public static void atualizar (Laboratorio laboratorio) {
		  
		  try {
			  
			  Connection connection = ConexaoUtil.getInstance().getConnection();
			  String sql = "update laboratorio set idLaboratorio = ? where idLaboratorio =?";
			  PreparedStatement statement = connection.prepareStatement(sql);
			  
			  statement.setInt(1,laboratorio.getIdLaboratorio());

			    statement.execute();
				statement.close();		
			  
		  }catch(Exception e) {
			  e.printStackTrace();
		  }
		  
		  
	  }
}

