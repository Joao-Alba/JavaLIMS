package tabelas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class Control_Laboratorio {

	
	public  static void inserir(Laboratorio laboratorio) {
		try {
		Connection connection = ConexaoUtil.getInstance().getConnection();
		
		String sql  = "insert into Laboratorio(idLaboratorio, nome, cnpj, senha, planta)values (?,?,?,?,?)";
		
		PreparedStatement statement = connection.prepareStatement(sql);
	
		statement.setInt(1, laboratorio.getIdLaboratorio());
		statement.setString(2, laboratorio.getNome());
		statement.setString(3, laboratorio.getCnpj());
		statement.setString(4, laboratorio.getSenha());
		statement.setString(5, "oi");
		
		statement.execute();
		connection.close();
		
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	public static  void remover(int idLaboratorio) {
		try {
			Connection connection = ConexaoUtil.getInstance().getConnection();
			String sql = "delete from Laboratorio where idLaboratorio = ?";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setInt(1, idLaboratorio);
			
			statement.execute();
			statement.close();
		}catch (Exception e) {
		}
	}
	  public static List<Laboratorio> listarTodos(){
			
		List<Laboratorio> listarLaboratorios = new ArrayList<Laboratorio>();
		try {
			Connection connection = ConexaoUtil.getInstance().getConnection();
			String sql = "select * from Laboratorio";
			
			PreparedStatement statement = connection.prepareStatement(sql);
			ResultSet resultset = statement.executeQuery();
			while(resultset.next()) {
				
			Laboratorio laboratorio = new Laboratorio();
			laboratorio.setIdLaboratorio(resultset.getInt(1));
			laboratorio.setNome(resultset.getString("Nome"));
			laboratorio.setCnpj(resultset.getString("Cnpj"));
			laboratorio.setSenha(resultset.getString("Senha"));
			
			listarLaboratorios.add(laboratorio);
			
		}
		connection.close();
	}catch (Exception e) {
		e.printStackTrace();
	}
		return listarLaboratorios;
	  }
	  
	  public static void atualizar (Laboratorio laboratorio) {
		  
		  try {
			  
			  Connection connection = ConexaoUtil.getInstance().getConnection();
			  String sql = "update laboratorio set idLaboratorio = ? where idLaboratorio =?";
			  PreparedStatement statement = connection.prepareStatement(sql);
			  
			  statement.setInt(1,laboratorio.getIdLaboratorio());

			    statement.execute();
				statement.close();		
			  
		  }catch(Exception e) {
			  e.printStackTrace();
		  }
		  
		  
	  }
}

