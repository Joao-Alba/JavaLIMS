package tabelas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;



public class Control_Padrao {

	
	public static  void inserir(Padrao padrao) {
		try {
		Connection connection = ConexaoUtil.getInstance().getConnection();
		
		String sql  = "insert into Padrao(idPadrao,idAnalito,idMaquina,Maximo,Minimo)values (?,?,?,?,?)";
		
		PreparedStatement statement = connection.prepareStatement(sql);
	
		statement.setInt(1, padrao.getIdPadrao());
		statement.setInt(2, padrao.getIdPadrao());
		statement.setInt(3, padrao.getIdPadrao());
		statement.setInt(4, padrao.getIdPadrao());
		statement.setInt(5, padrao.getIdPadrao());
		
		
		statement.execute();
		connection.close();
		
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	public static  void remover(int idPadrao) {
		try {
			Connection connection = ConexaoUtil.getInstance().getConnection();
			String sql = "delete from padrao where idPadrao = ?";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setInt(1, idPadrao);
			statement.execute();
			statement.close();
		}catch (Exception e) {
		}
	}
	  public static  List<Padrao> listarTodos(){
		
		List<Padrao> listarPadroes = new ArrayList<Padrao>();
		try {
			Connection connection = ConexaoUtil.getInstance().getConnection();
			String sql = "select * from padrao";
			
			PreparedStatement statement = connection.prepareStatement(sql);
			ResultSet resultset = statement.executeQuery();
			while(resultset.next()) {
				
			Padrao padroes = new Padrao();
			padroes.setIdPadrao(resultset.getInt("IdPadroes"));
			padroes.setFk_idAnalito(resultset.getInt("analitos"));
			
			listarPadroes.add(padroes);
			
		}
		connection.close();
	}catch (Exception e) {
		e.printStackTrace();
	}
		return listarPadroes;
	  }
	  public static void atualizar (Padrao padrao) {
		  
		  try {
			  
			  Connection connection = ConexaoUtil.getInstance().getConnection();
			  String sql = "update padrao set idPadrao = ? where idPadrao =?";
			  PreparedStatement statement = connection.prepareStatement(sql);
			  
			  statement.setInt(1,padrao.getIdPadrao());
			  statement.setInt(2,padrao.getFk_idAnalito());

			    statement.execute();
				statement.close();		
			  
		  }catch(Exception e) {
			  e.printStackTrace();
		  }
	}
}

