package tabelas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;



public  class Control_Reagente {

	
	public static  void inserir( Reagente  reagente) {
		try {
		Connection connection = ConexaoUtil.getInstance().getConnection();
		
		String sql  = "insert into Reagente(idReagente,Nome,Formula,Precaucao,molaridade,preparador,qtd_Minima,qtd_Atual)values (?,?,?,?,?,?,?,?)";
		
		PreparedStatement statement = connection.prepareStatement(sql);
	
		statement.setInt(1, reagente.getIdReagente());
		statement.setString(2, reagente.getNome());
		statement.setString(3, reagente.getFormula());
		statement.setString(4, reagente.getPrecaucao());
		statement.setString(5, reagente.getMolaridade());
		statement.setString(6, reagente.getPreparador());
		statement.setDouble(7, reagente.getIdReagente());
		statement.setDouble(8, reagente.getIdReagente());
		
		
		statement.execute();
		connection.close();
		
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	public static  void remover(int idReagente) {
		try {
			Connection connection = ConexaoUtil.getInstance().getConnection();
			String sql = "delete from Reagente where idReagente = ?";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setInt(1, idReagente);
			statement.execute();
			statement.close();
		}catch (Exception e) {
		}
	}
	  public static List<Reagente> listarTodos(){
		
		List<Reagente> listarReagente = new ArrayList<Reagente>();
		try {
			Connection connection = ConexaoUtil.getInstance().getConnection();
			String sql = "select * from reagente";
			
			PreparedStatement statement = connection.prepareStatement(sql);
			ResultSet resultset = statement.executeQuery();
			while(resultset.next()) {
				
			Reagente reagentes = new Reagente();
			reagentes.setIdReagente(resultset.getInt(1));
			reagentes.setNome(resultset.getString("Labmil"));
			reagentes.setFormula(resultset.getString("ac2"));
			reagentes.setPrecaucao(resultset.getString("fogo"));
			reagentes.setMolaridade(resultset.getString("temp"));
			reagentes.setPreparador(resultset.getString("Super"));
			reagentes.setQtd_Minima(resultset.getDouble(7));
			reagentes.setQtd_Atual(resultset.getDouble(8));
			
			
			
			listarReagente.add(reagentes);
			
		}
		connection.close();
	}catch (Exception e) {
		e.printStackTrace();
	}
		return listarReagente;
	  }
	  public static void atualizar (Reagente reagentes) {
		  
		  try {
			  
			  Connection connection = ConexaoUtil.getInstance().getConnection();
			  String sql = "update Reagente set idReagente = ? where idReagente =?";
			  PreparedStatement statement = connection.prepareStatement(sql);
			  
			  statement.setInt(1,reagentes.getIdReagente());
			  statement.setString(2,reagentes.getNome());
			  statement.setString(3,reagentes.getFormula());
			  statement.setString(4,reagentes.getPrecaucao());
			  statement.setString(5,reagentes.getMolaridade());
			  statement.setString(6,reagentes.getPreparador());
			  statement.setDouble(7,reagentes.getQtd_Minima());
			  statement.setDouble(8,reagentes.getQtd_Atual());
			  
			  
			  

			    statement.execute();
				statement.close();		
			  
		  }catch(Exception e) {
			  e.printStackTrace();
		  }
		  
		  
	  }
	  public static void main(String[]args) {
		  
		  Reagente  reagentes = new Reagente();
		  reagentes.setIdReagente(1);
		  reagentes.setNome("Sulfuroso");
		  reagentes.setFormula("balistico");
          reagentes.setPrecaucao("Fogo");	
          reagentes.setMolaridade("Cro1");
          reagentes.setPreparador("Cd2");
          
          
		  inserir(reagentes);
		  
	  }
}

